<?php
$DB_SERVER="localhost";
$DB_USER="db";
$DB_PASS="";
$DB_NAME="flags"
?>
-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2019 at 07:16 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lab6_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `markers`
--

CREATE TABLE `markers` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `address` varchar(80) NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  `type` varchar(30) NOT NULL,
  `description` varchar(300) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `markers`
--

INSERT INTO `markers` (`id`, `name`, `address`, `lat`, `lng`, `type`, `description`) VALUES
(1, 'Water Treatment Plant', '3895  Snowbird Lane, Small-Town, USA', 40.044376, -83.167770, 'utility', 'Please add a location (IP Addresss) & description of the tasks'),
(2, 'Nuclear Power Plant', '76 Wilford Street, Small-Town, USA', 39.794983, -83.155144, 'powerN', 'Please add a location (IP Addresss) & description of the tasks'),
(3, 'Hospital', '4796  Clark Street, Small-Town, USA', 39.979519, -82.842537, 'hospital', 'Please add a location (IP Addresss) & description of the tasks'),
(4, 'Air Port', '7A, 2 Huntley Street, Small-Town, USA', 39.822102, -82.940018, 'transitA', 'Please add a location (IP Addresss) & description of the tasks'),
(5, 'Rail Station', '16 Foster Street, Small-Town, USA', 39.973320, -82.995689, 'transitR', 'Please add a location (IP Addresss) & description of the tasks'),
(6, 'Power Grid', '43 Macpherson Street, Small-Town, USA', 39.974689, -83.032928, 'powerG', 'Please add a location (IP Addresss) & description of the tasks');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `markers`
--
ALTER TABLE `markers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `markers`
--
ALTER TABLE `markers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

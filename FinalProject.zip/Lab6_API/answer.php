<?php
// Connect to your MySQL database
require("constant.php") 

/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect('$DB_SERVER', '$DB_USER', '$DB_PASS', '$DB_NAME');
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$system_name = mysqli_real_escape_string($link, $_GET['type']);
$flag = mysqli_real_escape_string($link, $_GET['flag']);
$points = mysqli_real_escape_string($link, $_GET['points']);

// Getting variables
$answer = $_POST[$flag];
$type = $_POST[$system_name];

// Comparing answers Still having trouble with this. Having a T_Variable Error.

try {

    $stmt = mysqli_query($link,'SELECT * FROM flags WHERE type='" .$type. "' and answer='".$answer. "' LIMIT 0,1');
    $stmt->execute();

    $result = $stmt->fetchAll();

    //trying something different here. The type variable which represents the system name,
    //should match the form input, then the database should reference that row, and pull the flag
    //variable. Which we should than compare. If they match, the competitors get the points.
    //if not, they are told to try again. The code below is a work in progress.
    if ($type == $type && $answer == $answer) {

    foreach($result as $row) { 

    echo 'OK, you've entered a correct answer';
    // Do Something Else

    }} else {

    echo 'ERROR: Seems like you didn't put the correct answer. Please try again';
    exit;

    }} catch(PDOException $e) {

    echo 'ERROR: ' . $e->getMessage();

    }


    // close connection
mysqli_close($link);
?>

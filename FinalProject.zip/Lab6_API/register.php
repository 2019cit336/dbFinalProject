<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "db", "", "registration");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
if (isset($_POST['name'])) {
    $name = mysqli_real_escape_string($link, $_POST['name']);
}

if (isset($_POST['email'])) {
    $email_address = mysqli_real_escape_string($link, $_POST['email']);
}

if (isset($_POST['school'])) {
    $school = mysqli_real_escape_string($link, $_POST['school']);
}
if (isset($_POST['experience'])) {
    $experience = mysqli_real_escape_string($link, $_POST['experience']);
}


// attempt insert query execution
$sql = "INSERT INTO users (full_name, email, school, experience) VALUES ('$name', '$email_address', '$school', '$experience')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>

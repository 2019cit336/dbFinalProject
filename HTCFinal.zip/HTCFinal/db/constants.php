<?php
$DB_SERVER="localhost";
$DB_USER="db";
$DB_PASS="";
$DB_NAME="lab6_data"
?>